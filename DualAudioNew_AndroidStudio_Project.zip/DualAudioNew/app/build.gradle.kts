plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.dualaudionew"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.dualaudionew"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
