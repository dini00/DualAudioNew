package com.example.dualaudionew

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class DualAudioService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_WIRED_ID = "wired_id"
        const val EXTRA_BT_ID = "bt_id"
        private const val CHANNEL_ID = "dual_audio_channel"
        private const val NOTIFICATION_ID = 31
        private const val TAG = "DualAudioNew"
    }

    private val running = AtomicBoolean(false)
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var wiredTrack: AudioTrack? = null
    private var bluetoothTrack: AudioTrack? = null
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Starting dual audio…"))

        stopAudioPipeline()

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        @Suppress("DEPRECATION")
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        val wiredId = intent.getIntExtra(EXTRA_WIRED_ID, -1)
        val btId = intent.getIntExtra(EXTRA_BT_ID, -1)

        if (resultData == null || wiredId < 0 || btId < 0) {
            Log.e(TAG, "Missing projection result or selected output IDs")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.i(TAG, "MediaProjection stopped by system/user")
                    stopAudioPipeline()
                    stopSelf()
                }
            }, null)

            startAudioPipeline(wiredId, btId)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to start audio capture", e)
            stopAudioPipeline()
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun startAudioPipeline(wiredId: Int, btId: Int) {
        val p = projection ?: return
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).associateBy { it.id }
        val wired = outputs[wiredId]
        val bluetooth = outputs[btId]

        if (wired == null || bluetooth == null) {
            Log.e(TAG, "Selected output disappeared; reconnect devices and retry.")
            stopSelf()
            return
        }

        val sampleRate = 48000
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()

        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            Log.e(TAG, "Unsupported AudioRecord format: $minBuffer")
            stopSelf()
            return
        }
        val bufferSize = (minBuffer * 2).coerceAtLeast(8192)

        val captureConfig = android.media.AudioPlaybackCaptureConfiguration.Builder(p)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .build()

        val inputFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()

        recorder = AudioRecord.Builder()
            .setAudioFormat(inputFormat)
            .setBufferSizeInBytes(bufferSize)
            .setAudioPlaybackCaptureConfig(captureConfig)
            .build()

        val outFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
            .build()

        fun createTrack(device: AudioDeviceInfo): AudioTrack {
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(outFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            val accepted = track.setPreferredDevice(device)
            Log.i(TAG, "Requested ${device.productName} id=${device.id}; preferred accepted=$accepted")
            return track
        }

        wiredTrack = createTrack(wired)
        bluetoothTrack = createTrack(bluetooth)

        Log.i(TAG, "Wired track routed device=${wiredTrack?.routedDevice?.productName}, id=${wiredTrack?.routedDevice?.id}")
        Log.i(TAG, "Bluetooth track routed device=${bluetoothTrack?.routedDevice?.productName}, id=${bluetoothTrack?.routedDevice?.id}")

        try {
            recorder?.startRecording()
            wiredTrack?.play()
            bluetoothTrack?.play()
            running.set(true)
            updateNotification("Dual audio running — routing is device-dependent")
            worker = thread(name = "DualAudioCapture", isDaemon = true) {
                val buffer = ByteArray(bufferSize)
                while (running.get()) {
                    val count = try {
                        recorder?.read(buffer, 0, buffer.size) ?: -1
                    } catch (e: Exception) {
                        Log.e(TAG, "AudioRecord read failed", e)
                        -1
                    }
                    if (count > 0) {
                        val first = wiredTrack?.write(buffer, 0, count) ?: -1
                        val second = bluetoothTrack?.write(buffer, 0, count) ?: -1
                        if (first < 0 || second < 0) {
                            Log.e(TAG, "AudioTrack write error: wired=$first bluetooth=$second")
                        }
                    } else if (count < 0) {
                        Log.e(TAG, "Audio capture read error: $count")
                        break
                    }
                }
                Log.i(TAG, "Capture loop ended")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Audio pipeline start failed", e)
            stopAudioPipeline()
            stopSelf()
        }
    }

    private fun stopAudioPipeline() {
        running.set(false)
        try { worker?.join(300) } catch (_: InterruptedException) {}
        worker = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { wiredTrack?.pause() } catch (_: Exception) {}
        try { wiredTrack?.flush() } catch (_: Exception) {}
        try { wiredTrack?.release() } catch (_: Exception) {}
        wiredTrack = null
        try { bluetoothTrack?.pause() } catch (_: Exception) {}
        try { bluetoothTrack?.flush() } catch (_: Exception) {}
        try { bluetoothTrack?.release() } catch (_: Exception) {}
        bluetoothTrack = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Dual Audio", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Dual Audio New")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Dual Audio New")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        }
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        stopAudioPipeline()
        super.onDestroy()
    }
}
