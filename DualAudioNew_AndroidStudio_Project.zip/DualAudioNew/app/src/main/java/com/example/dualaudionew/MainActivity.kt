package com.example.dualaudionew

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var audioManager: AudioManager
    private lateinit var wiredSpinner: Spinner
    private lateinit var bluetoothSpinner: Spinner
    private lateinit var status: TextView
    private var devices: List<AudioDeviceInfo> = emptyList()

    private val projectionRequest = 701
    private val audioPermissionRequest = 702
    private var pendingCaptureAfterPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }

        val title = TextView(this).apply {
            text = "Dual Audio New"
            textSize = 25f
        }
        root.addView(title)

        val explanation = TextView(this).apply {
            text = "Capture audio from other apps (when allowed by Android) and try to play it through wired and Bluetooth outputs simultaneously."
            textSize = 15f
            setPadding(0, 12, 0, 18)
        }
        root.addView(explanation)

        root.addView(TextView(this).apply { text = "Wired output"; textSize = 17f })
        wiredSpinner = Spinner(this)
        root.addView(wiredSpinner, matchWidth())

        root.addView(TextView(this).apply {
            text = "Bluetooth output"
            textSize = 17f
            setPadding(0, 14, 0, 0)
        })
        bluetoothSpinner = Spinner(this)
        root.addView(bluetoothSpinner, matchWidth())

        val refresh = Button(this).apply {
            text = "Refresh devices"
            setOnClickListener { refreshDevices() }
        }
        root.addView(refresh, matchWidth())

        val start = Button(this).apply {
            text = "Start Dual Audio"
            setOnClickListener { requestCapture() }
        }
        root.addView(start, matchWidth())

        val stop = Button(this).apply {
            text = "Stop Dual Audio"
            setOnClickListener {
                stopService(Intent(this@MainActivity, DualAudioService::class.java))
                status.text = "Stopped."
            }
        }
        root.addView(stop, matchWidth())

        status = TextView(this).apply {
            text = "Connect wired earphones and Bluetooth earbuds, then refresh devices."
            textSize = 14f
            setPadding(0, 18, 0, 0)
        }
        root.addView(status)

        setContentView(root)
        refreshDevices()
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun refreshDevices() {
        devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val wired = devices.filter { isWired(it) }
        val bluetooth = devices.filter { isBluetooth(it) }

        wiredSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            wired.map { "${it.productName} (id ${it.id})" }.ifEmpty { listOf("No wired output found") }
        )
        bluetoothSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            bluetooth.map { "${it.productName} (id ${it.id})" }.ifEmpty { listOf("No Bluetooth output found") }
        )

        wiredSpinner.tag = wired
        bluetoothSpinner.tag = bluetooth

        status.text = "Found ${wired.size} wired and ${bluetooth.size} Bluetooth output(s)."
    }

    private fun isWired(d: AudioDeviceInfo): Boolean = when (d.type) {
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_USB_ACCESSORY -> true
        else -> false
    }

    private fun isBluetooth(d: AudioDeviceInfo): Boolean = when (d.type) {
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_BLE_SPEAKER -> true
        else -> false
    }

    private fun requestCapture() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            pendingCaptureAfterPermission = true
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        beginProjectionRequest()
    }

    private fun beginProjectionRequest() {
        val wiredList = wiredSpinner.tag as? List<*> ?: emptyList<Any>()
        val btList = bluetoothSpinner.tag as? List<*> ?: emptyList<Any>()
        val wired = wiredList.getOrNull(wiredSpinner.selectedItemPosition) as? AudioDeviceInfo
        val bluetooth = btList.getOrNull(bluetoothSpinner.selectedItemPosition) as? AudioDeviceInfo

        if (wired == null || bluetooth == null) {
            Toast.makeText(this, "Connect both wired and Bluetooth devices first.", Toast.LENGTH_LONG).show()
            return
        }

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        pendingWiredId = wired.id
        pendingBluetoothId = bluetooth.id
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    private var pendingWiredId = -1
    private var pendingBluetoothId = -1


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && pendingCaptureAfterPermission) {
            pendingCaptureAfterPermission = false
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                beginProjectionRequest()
            } else {
                status.text = "Microphone/audio capture permission is required."
                Toast.makeText(this, "Please allow audio capture permission.", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Uses the platform MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, DualAudioService::class.java).apply {
                putExtra(DualAudioService.EXTRA_RESULT_CODE, resultCode)
                putExtra(DualAudioService.EXTRA_RESULT_DATA, data)
                putExtra(DualAudioService.EXTRA_WIRED_ID, pendingWiredId)
                putExtra(DualAudioService.EXTRA_BT_ID, pendingBluetoothId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
            status.text = "Capture started. Check notification/logs for actual routing status."
        } else {
            status.text = "Audio capture permission was not granted."
        }
    }
}
